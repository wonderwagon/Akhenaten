g_config.colors = {
  black : 0xff000000,
  red : 0xffff0000,
  grey : 0xffbebebe
}
