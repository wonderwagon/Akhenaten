g_config.entertainment = {}

g_config.entertainment.shows = [
    { text : "##showing_agamemnon_aeschylus##", name : "", author : "" },
    { text : "##showing_antigone_sophocles##",  },
    { text : "##showing_lisistrata_aristopanes##", },
    { text : "##showing_lisistrata_aristopanes##", },
    { text : "##showing_odyssey_homer##" }
  ]
