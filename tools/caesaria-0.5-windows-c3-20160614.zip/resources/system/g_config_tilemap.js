g_config.tilemap = {
  CheckCorners:1,
  FourNeighbors:2,
  AllNeighbors:3
}
