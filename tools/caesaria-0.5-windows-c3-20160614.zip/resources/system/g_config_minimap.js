g_config.minimap = {}

g_config.minimap.colors = {
    tree : [ "0x00ff00", "0x00ff00" ],
    rock : [ "0x000000", "0x000000" ],
    water : [ "0x000000", "0x000000" ],
    wall : [ "0x000000", "0x000000" ],
    road : [ "0x000000", "0x000000" ],
    agressive : [ "0xff0000", "0xff0000" ],
}
