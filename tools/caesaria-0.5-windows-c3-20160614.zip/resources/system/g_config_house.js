g_config.house = {}

g_config.house.level = {
  vacantLot:0,
  hovel:1,
  tent:2,
  shack:3,
  hut:4, //4
  domus:5,
  bigDomus:6, //6
  mansion:7,
  bigMansion:8, //8
  insula:9,
  middleInsula:10,   //10
  bigInsula:11,
  beatyfullInsula:12, //12
  smallVilla:13,
  middleVilla:14,
  bigVilla:15,
  greatVilla:16,
  smallPalace:17,
  middlePalace:18,
  bigPalace:19,
  greatPalace:20,
  maxLevel:20 
}
