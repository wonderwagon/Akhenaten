var g_paths = {}
