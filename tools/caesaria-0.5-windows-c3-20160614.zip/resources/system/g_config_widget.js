g_config.widget.state = {
  stNormal:0,
  stPressed:1,
  stHovered:2,
  stDisabled:3,
  stChecked:4,
  stCount:5
} 
