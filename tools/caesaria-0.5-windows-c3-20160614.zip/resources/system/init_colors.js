g_config.colors = {
  black : 0xff000000,
  grey : 0xffbebebe
}
